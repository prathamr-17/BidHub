/**
 * Shared types for the OneMap Copilot module.
 * Teammates: map your own issue objects onto `IssueContext` before passing
 * them to <CopilotDrawer />.
 */

/** Traffic-light status of an issue. */
export type IssueStatus = "red" | "yellow" | "green";

/** Everything the Copilot needs to know about the issue the user selected. */
export interface IssueContext {
  id: string;
  /** e.g. "Pothole", "Broken Streetlight", "Water Leakage" */
  category: string;
  status: IssueStatus;
  /** Human-readable place, e.g. "Andheri East, near Metro Station" */
  locationName: string;
  description: string;
  /** Optional photo of the issue (shown in the drawer, not sent to the model). */
  imageUrl?: string;
  /** ISO 8601 string, e.g. "2026-09-28T09:30:00Z" */
  date: string;
}

/** A single chat bubble in the Copilot drawer. */
export interface CopilotMessage {
  id: string;
  role: "user" | "assistant";
  /** For user messages this is the exact prompt sent to the API. */
  content: string;
  /** Optional short text shown in the bubble instead of `content` (used by quick actions). */
  label?: string;
  /** True when this assistant bubble is an error notice. */
  isError?: boolean;
  /** Prompt to re-send when the user presses "Try again" on an error bubble. */
  retryPrompt?: string;
}

/** Previous turns sent along so follow-up questions have context. */
export interface CopilotHistoryItem {
  role: "user" | "assistant";
  content: string;
}

/** POST /api/copilot request body. */
export interface CopilotRequestBody {
  issueContext: IssueContext;
  userPrompt: string;
  history?: CopilotHistoryItem[];
}

/** POST /api/copilot response body. */
export type CopilotResponseBody = { text: string } | { error: string };
