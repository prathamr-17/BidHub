"use client";

import { FormEvent, useCallback, useEffect, useRef, useState } from "react";
import ReactMarkdown, { type Components } from "react-markdown";
import type {
  CopilotHistoryItem,
  CopilotMessage,
  IssueContext,
  IssueStatus,
} from "@/types/issue";

/* -------------------------------------------------------------------------- */
/*  Config                                                                     */
/* -------------------------------------------------------------------------- */

// Status labels live here so the team can rename them in one place.
const STATUS_META: Record<IssueStatus, { label: string; dot: string; badge: string }> = {
  red: {
    label: "Urgent",
    dot: "bg-red-500",
    badge: "border-red-200 bg-red-50 text-red-800",
  },
  yellow: {
    label: "In progress",
    dot: "bg-amber-400",
    badge: "border-amber-200 bg-amber-50 text-amber-900",
  },
  green: {
    label: "Resolved",
    dot: "bg-emerald-500",
    badge: "border-emerald-200 bg-emerald-50 text-emerald-800",
  },
};

const QUICK_ACTIONS = [
  {
    label: "⚡ Immediate Safety Steps",
    prompt:
      "What should I do right now to stay safe around this issue, and what should I warn other people about? Give me prioritized steps.",
  },
  {
    label: "📜 Draft Escalation Email",
    prompt:
      "Draft a short, formal escalation email to the responsible municipal authority about this issue. Include a subject line, the key facts from the report, and a clear request with a timeframe.",
  },
  {
    label: "📞 Emergency Contacts",
    prompt:
      "Who should I contact about this issue? List the right emergency services or municipal helplines for this location and category, and when to use each.",
  },
] as const;

const REQUEST_TIMEOUT_MS = 30_000;

const FOCUS_RING =
  "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 focus-visible:ring-offset-1";

/* -------------------------------------------------------------------------- */
/*  Helpers                                                                    */
/* -------------------------------------------------------------------------- */

const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

function formatDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

/**
 * Turns a thread into history for the API. Only complete user→assistant pairs
 * are kept, so failed or unanswered prompts never leak into later requests.
 */
function buildHistory(thread: CopilotMessage[]): CopilotHistoryItem[] {
  const clean = thread.filter((m) => !m.isError);
  const history: CopilotHistoryItem[] = [];
  for (let i = 0; i < clean.length; i++) {
    const current = clean[i];
    const next = clean[i + 1];
    if (current.role === "user" && next?.role === "assistant") {
      history.push(
        { role: "user", content: current.content },
        { role: "assistant", content: next.content },
      );
      i++;
    }
  }
  return history;
}

function friendlyError(err: unknown): string {
  if (err instanceof DOMException && (err.name === "TimeoutError" || err.name === "AbortError")) {
    return "Copilot took too long to respond.";
  }
  if (err instanceof TypeError) {
    return "Couldn't reach the server. Check your connection.";
  }
  if (err instanceof Error && err.message) return err.message;
  return "Something went wrong.";
}

/* -------------------------------------------------------------------------- */
/*  Small presentational pieces                                                */
/* -------------------------------------------------------------------------- */

const mdComponents: Components = {
  p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
  ul: ({ children }) => <ul className="mb-2 list-disc space-y-1 pl-5 last:mb-0">{children}</ul>,
  ol: ({ children }) => <ol className="mb-2 list-decimal space-y-1 pl-5 last:mb-0">{children}</ol>,
  li: ({ children }) => <li className="pl-0.5">{children}</li>,
  strong: ({ children }) => <strong className="font-semibold text-slate-900">{children}</strong>,
  h1: ({ children }) => <p className="mb-1 font-semibold text-slate-900">{children}</p>,
  h2: ({ children }) => <p className="mb-1 font-semibold text-slate-900">{children}</p>,
  h3: ({ children }) => <p className="mb-1 font-semibold text-slate-900">{children}</p>,
  hr: () => <hr className="my-3 border-slate-200" />,
  code: ({ children }) => (
    <code className="rounded bg-slate-100 px-1 py-0.5 text-[0.85em]">{children}</code>
  ),
  a: ({ href, children }) => (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="font-medium text-teal-700 underline underline-offset-2"
    >
      {children}
    </a>
  ),
};

function SparkIcon({ className = "h-4 w-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M12 2l1.8 5.2L19 9l-5.2 1.8L12 16l-1.8-5.2L5 9l5.2-1.8L12 2zm7 11l.9 2.6 2.6.9-2.6.9L19 20l-.9-2.6-2.6-.9 2.6-.9L19 13z" />
    </svg>
  );
}

function StrokeIcon({ children }: { children: React.ReactNode }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      className="h-4 w-4"
      aria-hidden="true"
    >
      {children}
    </svg>
  );
}

function CopilotAvatar() {
  return (
    <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-teal-700 text-white">
      <SparkIcon className="h-3.5 w-3.5" />
    </span>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => () => clearTimeout(timer.current), []);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard unavailable (e.g. insecure context) — fail silently */
    }
  };

  return (
    <button
      type="button"
      onClick={handleCopy}
      className={`mt-2 inline-flex items-center gap-1.5 rounded-md px-1.5 py-1 text-xs font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-800 ${FOCUS_RING}`}
    >
      <StrokeIcon>
        <rect x="9" y="9" width="11" height="11" rx="2" />
        <path d="M5 15V6a2 2 0 012-2h9" />
      </StrokeIcon>
      {copied ? "Copied" : "Copy"}
    </button>
  );
}

/** Shows the user exactly what the Copilot is looking at. */
function IssueSummary({ issue }: { issue: IssueContext }) {
  const [imageFailed, setImageFailed] = useState(false);
  const showImage = Boolean(issue.imageUrl) && !imageFailed;

  return (
    <div className="flex gap-3 rounded-xl border border-slate-200 bg-white p-3">
      {showImage && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={issue.imageUrl}
          alt={`Reported ${issue.category.toLowerCase()}`}
          onError={() => setImageFailed(true)}
          className="h-16 w-16 shrink-0 rounded-lg object-cover"
        />
      )}
      <div className="min-w-0">
        <p className="text-xs text-slate-500">Reported {formatDate(issue.date)}</p>
        <p className="mt-0.5 line-clamp-3 text-sm text-slate-700">
          {issue.description || "No description provided."}
        </p>
      </div>
    </div>
  );
}

/* -------------------------------------------------------------------------- */
/*  Main component                                                             */
/* -------------------------------------------------------------------------- */

interface CopilotDrawerProps {
  /** The issue the user clicked in the list, or null when nothing is selected. */
  selectedIssue: IssueContext | null;
  /** Called when the user closes the drawer (deselect the issue in the parent). */
  onClose?: () => void;
}

export default function CopilotDrawer({ selectedIssue, onClose }: CopilotDrawerProps) {
  // Conversations are kept per issue, so switching issues never mixes context.
  const [threads, setThreads] = useState<Record<string, CopilotMessage[]>>({});
  const [pending, setPending] = useState<Record<string, boolean>>({});
  const [input, setInput] = useState("");
  const streamRef = useRef<HTMLDivElement>(null);

  const issue = selectedIssue;
  const thread = issue ? (threads[issue.id] ?? []) : [];
  const isPending = issue ? Boolean(pending[issue.id]) : false;
  const status = issue ? STATUS_META[issue.status] : null;

  // Keep the newest message in view.
  useEffect(() => {
    const el = streamRef.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [thread.length, isPending, issue?.id]);

  const addMessage = useCallback((issueId: string, message: CopilotMessage) => {
    setThreads((prev) => ({ ...prev, [issueId]: [...(prev[issueId] ?? []), message] }));
  }, []);

  const send = useCallback(
    async (prompt: string, opts: { label?: string; retry?: boolean } = {}) => {
      if (!issue) return;
      const text = prompt.trim();
      if (!text || pending[issue.id]) return;

      const issueId = issue.id;
      const history = buildHistory(threads[issueId] ?? []);

      if (!opts.retry) {
        addMessage(issueId, { id: makeId(), role: "user", content: text, label: opts.label });
        setInput("");
      }
      setPending((prev) => ({ ...prev, [issueId]: true }));

      try {
        const res = await fetch("/api/copilot", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ issueContext: issue, userPrompt: text, history }),
          signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
        });

        const data = (await res.json().catch(() => null)) as
          | { text?: string; error?: string }
          | null;

        if (!res.ok || !data?.text) {
          throw new Error(data?.error || "Copilot couldn't respond. Please try again.");
        }

        addMessage(issueId, { id: makeId(), role: "assistant", content: data.text });
      } catch (err) {
        addMessage(issueId, {
          id: makeId(),
          role: "assistant",
          content: friendlyError(err),
          isError: true,
          retryPrompt: text,
        });
      } finally {
        setPending((prev) => ({ ...prev, [issueId]: false }));
      }
    },
    [issue, pending, threads, addMessage],
  );

  const retry = (message: CopilotMessage) => {
    if (!issue || !message.retryPrompt) return;
    setThreads((prev) => ({
      ...prev,
      [issue.id]: (prev[issue.id] ?? []).filter((m) => m.id !== message.id),
    }));
    void send(message.retryPrompt, { retry: true });
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    void send(input);
  };

  const canSend = Boolean(issue) && !isPending && input.trim().length > 0;

  return (
    <aside
      aria-label="OneMap Copilot"
      className={`${
        issue ? "flex" : "hidden lg:flex"
      } fixed inset-0 z-40 flex-col bg-white lg:static lg:z-auto lg:h-full lg:w-[400px] lg:shrink-0 lg:border-l lg:border-slate-200`}
    >
      {/* Header */}
      <header className="border-b border-slate-200 px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-teal-700 text-white">
              <SparkIcon />
            </span>
            <h2 className="text-sm font-semibold text-slate-900">OneMap Copilot</h2>
          </div>
          {issue && onClose && (
            <button
              type="button"
              onClick={onClose}
              aria-label="Close Copilot"
              className={`rounded-md p-1.5 text-slate-500 transition hover:bg-slate-100 hover:text-slate-800 ${FOCUS_RING}`}
            >
              <StrokeIcon>
                <path d="M6 6l12 12M18 6L6 18" />
              </StrokeIcon>
            </button>
          )}
        </div>

        {issue && status && (
          <div className="mt-2.5 flex items-center gap-2">
            <span
              className={`inline-flex shrink-0 items-center gap-2 rounded-full border px-2.5 py-1 text-xs font-medium ${status.badge}`}
            >
              <span className={`h-2 w-2 rounded-full ${status.dot}`} aria-hidden="true" />
              {issue.category}
              <span className="h-3 w-px bg-current opacity-30" aria-hidden="true" />
              {status.label}
            </span>
            <span className="truncate text-xs text-slate-500" title={issue.locationName}>
              {issue.locationName}
            </span>
          </div>
        )}
      </header>

      {/* Quick actions */}
      <div className="flex flex-wrap gap-2 border-b border-slate-200 px-4 py-3">
        {QUICK_ACTIONS.map((action) => (
          <button
            key={action.label}
            type="button"
            disabled={!issue || isPending}
            onClick={() => void send(action.prompt, { label: action.label })}
            className={`rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 transition hover:border-teal-600 hover:text-teal-800 disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:border-slate-200 disabled:hover:text-slate-700 ${FOCUS_RING}`}
          >
            {action.label}
          </button>
        ))}
      </div>

      {/* Message stream */}
      <div
        ref={streamRef}
        className="min-h-0 flex-1 space-y-4 overflow-y-auto bg-slate-50 px-4 py-4"
        aria-live="polite"
      >
        {!issue ? (
          <div className="flex h-full flex-col items-center justify-center px-6 text-center">
            <span className="grid h-10 w-10 place-items-center rounded-full bg-teal-700/10 text-teal-700">
              <SparkIcon className="h-5 w-5" />
            </span>
            <p className="mt-3 text-sm font-medium text-slate-900">Select an issue to get help</p>
            <p className="mt-1 text-sm text-slate-500">
              Pick an issue from your list and Copilot will suggest safety steps, escalation
              options and who to contact.
            </p>
          </div>
        ) : (
          <>
            <IssueSummary key={issue.id} issue={issue} />

            {thread.length === 0 && !isPending && (
              <p className="px-1 text-sm text-slate-500">
                Ask anything about this issue, or start with one of the quick actions above.
              </p>
            )}

            {thread.map((msg) =>
              msg.role === "user" ? (
                <div key={msg.id} className="flex justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-br-sm bg-teal-700 px-3.5 py-2 text-sm text-white">
                    {msg.label ?? msg.content}
                  </div>
                </div>
              ) : (
                <div key={msg.id} className="flex items-start gap-2">
                  <CopilotAvatar />
                  <div
                    className={`min-w-0 max-w-[88%] rounded-2xl rounded-tl-sm border px-3.5 py-2.5 text-sm shadow-sm ${
                      msg.isError
                        ? "border-red-200 bg-red-50 text-red-800"
                        : "border-slate-200 bg-white text-slate-700"
                    }`}
                  >
                    {msg.isError ? (
                      <>
                        <p>{msg.content}</p>
                        {msg.retryPrompt && (
                          <button
                            type="button"
                            onClick={() => retry(msg)}
                            disabled={isPending}
                            className={`mt-2 rounded-md border border-red-300 bg-white px-2.5 py-1 text-xs font-medium text-red-800 transition hover:bg-red-100 disabled:opacity-50 ${FOCUS_RING}`}
                          >
                            Try again
                          </button>
                        )}
                      </>
                    ) : (
                      <>
                        <ReactMarkdown components={mdComponents}>{msg.content}</ReactMarkdown>
                        <CopyButton text={msg.content} />
                      </>
                    )}
                  </div>
                </div>
              ),
            )}

            {isPending && (
              <div className="flex items-start gap-2" role="status">
                <CopilotAvatar />
                <div className="rounded-2xl rounded-tl-sm border border-slate-200 bg-white px-3.5 py-2.5 text-sm text-slate-600 shadow-sm">
                  <span className="flex items-center gap-2">
                    <span className="flex items-center gap-1" aria-hidden="true">
                      {[0, 150, 300].map((delay) => (
                        <span
                          key={delay}
                          style={{ animationDelay: `${delay}ms` }}
                          className="h-1.5 w-1.5 rounded-full bg-teal-600 motion-safe:animate-bounce"
                        />
                      ))}
                    </span>
                    Copilot is analyzing the issue…
                  </span>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-slate-200 bg-white px-4 pb-3 pt-3">
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={!issue}
            maxLength={1000}
            placeholder={issue ? "Ask about this issue…" : "Select an issue first"}
            aria-label="Ask Copilot a question"
            className={`min-w-0 flex-1 rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 disabled:bg-slate-100 ${FOCUS_RING}`}
          />
          <button
            type="submit"
            disabled={!canSend}
            aria-label="Send message"
            className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-teal-700 text-white transition hover:bg-teal-800 disabled:cursor-not-allowed disabled:bg-slate-300 ${FOCUS_RING}`}
          >
            <StrokeIcon>
              <path d="M22 2L11 13" />
              <path d="M22 2l-7 20-4-9-9-4 20-7z" />
            </StrokeIcon>
          </button>
        </form>
        <p className="mt-2 text-[11px] leading-snug text-slate-500">
          Copilot can make mistakes. In an emergency, call your local emergency number first.
        </p>
      </div>
    </aside>
  );
}
