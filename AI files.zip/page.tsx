"use client";

/**
 * INTEGRATION EXAMPLE for the "Your Issues" page.
 *
 * Teammates only need to:
 *   1. Keep a `selectedIssue` state (IssueContext | null).
 *   2. Set it when a list item is clicked.
 *   3. Render <CopilotDrawer selectedIssue={selectedIssue} /> as the right-hand
 *      column of a full-height flex row.
 *
 * Replace MOCK_ISSUES with your real data and map each item to IssueContext.
 */

import { useState } from "react";
import CopilotDrawer from "@/components/CopilotDrawer";
import type { IssueContext } from "@/types/issue";

const MOCK_ISSUES: IssueContext[] = [
  {
    id: "iss-101",
    category: "Pothole",
    status: "red",
    locationName: "Andheri East, near Metro Station",
    description:
      "Large pothole about 40 cm deep in the left lane. Two-wheelers are swerving into traffic to avoid it, especially at night.",
    date: "2026-09-28T09:30:00Z",
  },
  {
    id: "iss-102",
    category: "Broken Streetlight",
    status: "yellow",
    locationName: "Linking Road, Bandra West",
    description:
      "Three consecutive streetlights have been out for a week. The footpath is very dark after 8 PM.",
    date: "2026-09-25T18:10:00Z",
  },
  {
    id: "iss-103",
    category: "Water Leakage",
    status: "green",
    locationName: "Powai Lake Road",
    description: "Main pipeline leak flooding the road shoulder. Repaired by the water department.",
    date: "2026-09-12T07:45:00Z",
  },
];

const DOT: Record<IssueContext["status"], string> = {
  red: "bg-red-500",
  yellow: "bg-amber-400",
  green: "bg-emerald-500",
};

export default function YourIssuesPage() {
  const [selectedIssue, setSelectedIssue] = useState<IssueContext | null>(null);

  return (
    // Full-height row: issue list on the left, Copilot pinned on the right.
    <div className="flex h-screen overflow-hidden bg-white">
      <main className="min-w-0 flex-1 overflow-y-auto p-6">
        <h1 className="text-xl font-semibold text-slate-900">Your Issues</h1>

        <ul className="mt-4 space-y-2">
          {MOCK_ISSUES.map((issue) => {
            const isSelected = selectedIssue?.id === issue.id;
            return (
              <li key={issue.id}>
                <button
                  type="button"
                  onClick={() => setSelectedIssue(issue)}
                  aria-pressed={isSelected}
                  className={`w-full rounded-xl border p-4 text-left transition ${
                    isSelected
                      ? "border-teal-600 bg-teal-50/50"
                      : "border-slate-200 hover:border-slate-300"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`h-2.5 w-2.5 rounded-full ${DOT[issue.status]}`} />
                    <span className="font-medium text-slate-900">{issue.category}</span>
                  </div>
                  <p className="mt-1 text-sm text-slate-500">{issue.locationName}</p>
                </button>
              </li>
            );
          })}
        </ul>
      </main>

      <CopilotDrawer selectedIssue={selectedIssue} onClose={() => setSelectedIssue(null)} />
    </div>
  );
}
