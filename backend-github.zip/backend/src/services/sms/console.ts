import type {SmsProvider} from "./provider.js";export const consoleSms:SmsProvider={async send(phone,message){console.info(`SMS to ${phone}: ${message}`)}};
