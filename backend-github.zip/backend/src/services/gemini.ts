export type AiRaw={category?:string;subcategory?:string;confidence?:number;reason?:string;immediateActions?:string[]};
// MUST NEVER THROW. Return null on any failure.
export async function analyzeComplaint(input:{title:string;description:string;userCategory?:string;allowedCategories:string[];priority:"LOW"|"MEDIUM"|"HIGH"|"CRITICAL";image?:{buffer:Buffer;mimeType:string}}):Promise<AiRaw|null>{ void input; return null; }
