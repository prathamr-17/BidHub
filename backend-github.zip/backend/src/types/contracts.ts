export const PRIORITIES = ["LOW","MEDIUM","HIGH","CRITICAL"] as const;
export const STATUSES = ["REPORTED","ASSIGNED","IN_PROGRESS","RESOLVED"] as const;
export const ROLES = ["CITIZEN","WORKER","ADMIN"] as const;
export type Priority = typeof PRIORITIES[number]; export type Status = typeof STATUSES[number]; export type Role = typeof ROLES[number];
export const TRANSITIONS: Record<Status, Status[]> = {REPORTED:["ASSIGNED"],ASSIGNED:["IN_PROGRESS","REPORTED"],IN_PROGRESS:["RESOLVED","ASSIGNED"],RESOLVED:["IN_PROGRESS"]};
export const PRIORITY_RANK: Record<Priority,number> = {LOW:1,MEDIUM:2,HIGH:3,CRITICAL:4};
