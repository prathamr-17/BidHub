export const cleanText=(value:string,max:number)=>value.replace(/[\x00-\x1F\x7F]/g," ").replace(/<[^>]*>/g," ").replace(/\s+/g," ").trim().slice(0,max);
export const locationKey=(value?:string|null)=>value?cleanText(value,120).toLowerCase().replace(/[^a-z0-9]+/g," ").trim()||null:null;
