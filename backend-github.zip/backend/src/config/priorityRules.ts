export {detectPriority} from "../services/priority.js";
