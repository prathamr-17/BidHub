import {env} from "./env.js";export const thresholds={recurrenceRadiusM:env.RECUR_RADIUS_M,recurrenceWindowDays:env.RECUR_WINDOW_DAYS,recurrenceMinReports:env.RECUR_MIN_REPORTS};
