# ONEMAP API

All request and response fields use camelCase. Priorities, statuses, and roles are uppercase strings. Errors always have the form `{"error":{"code":"VALIDATION_ERROR","message":"Invalid request","details":[]}}`.

| Method | Path | Auth | Request / response |
|---|---|---|---|
| GET | `/health` | Public | `{"ok":true,"time":"..."}` |
| POST | `/auth/staff/login` | Public | `{username,password}` → `{token,user}` |
| GET | `/auth/me` | Token | `{user:{id,name,role,department}}` |
| POST | `/auth/otp/request` | Public | `{phone}` → `{resendAfterSec}` |
| POST | `/auth/otp/verify` | Public | `{phone,code}` → `{token,user}` |
| POST | `/complaints` | Optional token | Multipart: `category?`, `title`, `description`, `lat`, `lng`, `address?`, `locationLabel?`, `reporterLat?`, `reporterLng?`, and optional `photo`; returns created complaint, AI/routing/recurrence information |
| GET | `/complaints/:id` | Public | Public-safe complaint detail and timeline |
| GET | `/complaints/mine` | Token | `page,pageSize` → own paginated complaints |
| GET | `/complaints/assigned` | Worker | Open assigned work |
| GET | `/complaints` | Admin | filters `status,priority,category,page,pageSize` |
| GET | `/complaints/:id/related` | Admin | Same recurrence group |
| POST | `/complaints/:id/assign` | Admin | `{workerId}` → assignment |
| PATCH | `/complaints/:id/status` | Worker/Admin | `{status,note?}` → updated complaint |
| PATCH | `/complaints/:id/priority` | Admin | `{priority,reason?}` → override |
| POST | `/complaints/:id/route/dispatch` | Admin | simulated dispatch `{reference,mode}` |
| GET | `/map/markers` | Public | required `minLat,maxLat,minLng,maxLng`; optional category/priority/status/limit |
| GET | `/meta/categories` | Public | Category metadata |
| GET | `/helplines` | Public | India emergency helplines |
| GET | `/workers` | Admin | Worker workload totals |
| GET | `/dashboard/summary` | Admin | Zero-filled dashboard counts |
| GET | `/dashboard/recurring` | Admin | Recurrence groups |
| GET | `/dashboard/workers` | Admin | Worker performance |
| GET | `/dashboard/locations` | Admin | Top locations |
| POST | `/admin/demo/seed` | Admin | optional `{lat,lng}` → `{created}` |
| DELETE | `/admin/demo/seed` | Admin | `{deleted}` |

Example creation response: `{"id":"uuid","status":"REPORTED","category":"electrical","priority":"CRITICAL","prioritySource":"AUTO","recurrence":{"isRecurring":false,"count":1},"routing":{"authority":"Emergency Services (112)","escalation":true},"warnings":[]}`.

Error codes are `VALIDATION_ERROR`, `UNAUTHENTICATED`, `FORBIDDEN`, `NOT_FOUND`, `INVALID_TRANSITION`, `RATE_LIMITED`, `UPLOAD_INVALID`, `OTP_INVALID`, `OTP_EXPIRED`, `OTP_LOCKED`, `SMS_UNAVAILABLE`, and `INTERNAL`. For multipart requests the photo field is named `photo`; do not set `Content-Type` manually because the HTTP client must provide the multipart boundary.
