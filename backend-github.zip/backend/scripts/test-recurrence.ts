import {haversineM} from "../src/lib/geo.js";if(haversineM(19.076,72.8777,19.076,72.8777)!==0)process.exit(1);console.info("PASS recurrence geometry");
