# ONEMAP civic complaint backend

Express + TypeScript + Prisma/Postgres backend for map-based civic maintenance reports. Priority and workflow authority always remain server-side; Gemini is deliberately a stub until a teammate supplies an integration.

## Setup

1. Copy `.env.example` to `.env` and replace every required placeholder, especially both Neon connection URLs, JWT secret, OTP pepper, and staff passwords.
2. `npm install`
3. `npm run db:push`
4. `npm run seed`
5. `npm run dev`

Useful commands: `npm run build`, `npm run test:priority`, `npm run test:ai`, `npm run test:recurrence`, `npm run smoke`, `npm run verify`, and `npm run demo:reset -- --yes`. The demo reset deliberately deletes every complaint before creating the demo set.

## Environment

See `.env.example` for the complete names. Cloudinary is optional: missing credentials preserve the complaint and return a warning without a photo. `ALLOW_DEMO_OTP=true` permits only the comma-separated `DEMO_PHONES` to use `DEMO_OTP`; never use this for open production testing. The console SMS provider only logs a code in non-production.

## Deploying to Render

Set the service root directory to `backend`, configure the environment variables in Render, then use build command `npm ci --include=dev && npx prisma generate && npx prisma db push && npm run build` and start command `node dist/server.js`. Use a Neon Postgres database and its pooled URL for `DATABASE_URL`, direct URL for `DIRECT_URL`.

## Gemini teammate contract

Implement only `src/services/gemini.ts`, preserving its exported `AiRaw` type and the rule that `analyzeComplaint` must never throw and returns `null` for every failure. It receives title, description, optional user category, allowed categories, server-calculated priority, and optional image bytes. It may suggest only category/subcategory/advice; it can never decide priority, status, or assignment.
